using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using System.Drawing.Design;
using System.Reflection;


namespace AssemblyHelper
{
	public class AssemblyFilePicker : UITypeEditor
	{
			
		public AssemblyFilePicker(): base()
		{
		}
		
		public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value) 
		{
			if (provider != null) 
			{
				IWindowsFormsEditorService editorService = (IWindowsFormsEditorService)provider.GetService(typeof(IWindowsFormsEditorService));
				Control editorControl = editorService as Control;
				
				if (editorControl != null) 
				{
					OpenFileDialog openFileDialog = new OpenFileDialog();					
					
					openFileDialog.CheckFileExists = true;
					openFileDialog.DefaultExt = ".dll";
					openFileDialog.Multiselect = false;
					openFileDialog.Title = "Select an Assembly:";
					openFileDialog.Filter = "Assembly Files | *.dll";
					
					DialogResult result = openFileDialog.ShowDialog(editorControl);
					if (result == DialogResult.OK)
					{
						Assembly assembly = Assembly.LoadFrom( openFileDialog.FileName ) ;
						value = assembly;	
					}
					else
					{
						value = null;
					}
				}
			}
			
			return value;
		}
		
		public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context) 
		{
			return UITypeEditorEditStyle.Modal;
		}

	
	}






}

